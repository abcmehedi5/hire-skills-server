# pms_api

Production Tracking System API

# Run

1. npm install
2. npm start
